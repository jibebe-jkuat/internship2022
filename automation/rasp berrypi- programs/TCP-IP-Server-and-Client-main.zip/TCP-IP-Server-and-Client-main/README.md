# TCP-IP-Server-and-Client
A simple TCP/IP server a client to echo back message sent to server back to client. 

# Files
## Client.py
Contains python code for the client
## Server.py
Contains python code for the server


# Useful links:
## TCP/IP Explained
https://www.avast.com/c-what-is-tcp-ip#:~:text=TCP%2FIP%20stands%20for%20Transmission,network%20such%20as%20the%20internet.

## TCP/IP implementation in Python
http://pymotw.com/2/socket/tcp.html
